"""Secure examination-paper exchange, package format version 1."""

__version__ = "1.0.0"
